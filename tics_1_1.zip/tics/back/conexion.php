<?php
    $servername = "localhost";
    $database = "comedero";
    $username = "comedero";
    $password = "piermartiri";
    $conn = mysqli_connect($servername, $username, $password, $database);
    // Check connection

    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }
?>