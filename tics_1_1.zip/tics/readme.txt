Falta modificar datos de mascotas y usuarios.
Datos de calculo de comida segun imc.
Datos de obseisdad.
Mediciones:
    Poner imagen de la medicion de altura del animal.
    Buscar informacion de gatos.
    Cuanta comida dar segun la marca para cada comida segun su peso

        https://alimentosparaperro.cl/cuales-son-las-mejores-marcas-de-alimento-para-perros-en-chile/


        https://www.purina-latam.com/ec/proplan/perros/adult/razas-pequenas#overview 
        https://www.purina-latam.com/cl/proplan/gatos/adult/producto#overview
        https://www.purina-latam.com/cl/proplan/perros/adult/razas-medianas
        https://www.purina-latam.com/cl/proplan/perros/adult/razas-grandes     

        IMC GATOS 
            https://www.omnicalculator.com/biology/cat-bmi   
    ingresar peso del animal y calcular cuanta comida darle, 
    formulario de veces al dia y cual es su estado segun el imc calculado.

Poner pantalla led que muestre los valores del peso de la comida que se sirve,
de la temperatura del agua


6abril 
20 abril
22 abril --------
27 abril --------