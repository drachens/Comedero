<?php 
		include_once("header.php"); 
?>
<div class ="d-flex align-items-center justify-content-center col-12 pd-top h300">
	<div class="d-flex flex-column justify-content-center align-items-center abs-center rounded col-md-6 col-sm-12 mx-4">
		<p>¿Tienes una cuenta?, <a class="font-weight-bold" href="ingresa.php">Inicia sesión</a></p>
		<p>Si no tienes una cuenta, entonces <a class="font-weight-bold" href="register.php">Registrate</a></p>
	</div>
</div>
<div>
</div>

<?php 
		include_once("footer.php"); 
?>