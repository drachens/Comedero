<?php
    include_once("header.php");
    include_once("navbar.php");
?>
    <a href="redLogin.php?key=cerrar"><button class="btn btn-primary">Cerra Sesion</button></a>
<?php
    include_once("footer.php");
?>