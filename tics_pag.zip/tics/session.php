<?php
session_start();
$patas = $_GET["key"];
$_SESSION["poto"] = "ola";
header("Location: inicio.php");
exit();
?>