<?php
    include_once("header.php");
    include_once("navbar.php");
    session_start();
?>
<div class="d-flex flex-column justify-content-center align-items-center bd-highlight mb-3 mt-3">
    <div class="p-2 bd-highlight col-lg-6 col-md-8 col-sm-12 bg-black3 mt-2 ">
        <div class="d-flex flex-row bd-highlight mb-3 justify-content-center align-items-center">
            <div class="d-flex p-2 bd-highlight col-3 mt-2  ">
                <img class="img_mascota" src="fondo.jpg">
            </div>
            <div class="p-2 bd-highlight col-9">
                <div class ="d-flex flex-row bd-highlight col-12 pt-1 justify-content-center align-items-center">
                    <div class="d-flex bd-highlight col-12">
                        <h5>Lucifer</h5>
                        <?php echo($_SESSION['poto']); ?>
                    </div>                    
                </div>
                <div class ="d-flex flex-row bd-highlight col-12 pt-1">
                    <div class="bd-highlight col-6">
                        <p>Dueño: Italo.</p>
                    </div>
                    <div class="bd-highlight col-6">
                        <p>Edad: 24 meses.</p>
                    </div>                   
                </div>
                <div class ="d-flex flex-row bd-highlight col-12 pt-1">
                    <div class="bd-highlight col-6">
                        <p>Raza: Quiltro</p>
                    </div>
                    <div class="bd-highlight col-6">
                        <p>Comedero: 12</p>
                    </div>                   
                </div>                
            </div>
            
        </div>
            <div class ="d-flex justify-content-center bd-highlight col-12 mb-2">
                <div class ="d-flex mx-1">
                    <button class = "btn btn-success">VER</button>
                </div>
                <div class ="d-flex mx-1">
                    <button class = "btn btn-secondary">BORRAR</button>
                </div>    
            </div>
    </div>
    <div class="p-2 bd-highlight col-lg-6 col-md-8 col-sm-12 bg-black3 mt-2">
        <a href="agregar_mascota.php"><button type="button" class="btn btn-success btn-lg btn-block">Agregar Mascota</button></a>
    </div>  
</div>

<?php
    include_once("footer.php");
?>